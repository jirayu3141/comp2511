package unsw.enrolment;

public interface AssignComponent {
    public void showAssignmentDetails();

	public String getName();

	public void setMark(int mark);
}