package unsw.enrolment;

import java.util.ArrayList;
import java.util.List;

public class AssignComposite implements AssignComponent{
    String name;
    Integer mark;
    private List<AssignComponent> assignmentList = new ArrayList<AssignComponent>();

    public AssignComposite(String name) {
        this.name = name;
        this.mark = null;
    }

    
    public AssignComposite(String name, Integer mark) {
        this.name = name;
        this.mark = mark;
    }


	@Override
    public void showAssignmentDetails() {
        System.out.println("[COMPOSITE]" + this.name + " {");
        for (AssignComponent x: assignmentList) {
            x.showAssignmentDetails();
        }
        System.out.println("}");
    }

    public boolean addAssignment (AssignComponent ass) {
        assignmentList.add(ass);
        return true;
    }

    public void removeAssignment (AssignComponent ass) {
        assignmentList.remove(ass);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMark() {
        return mark;
    }

    public void setMark(Integer mark) {
        this.mark = mark;
    }


	public void setMark(String ass, int mark) {
        for (AssignComponent x: assignmentList) {
            if (x.getName().equals(ass)) {
                x.setMark(mark);
            }
        }
    }

    @Override
    public void setMark(int mark) {
        this.mark = mark;
    }

    
}